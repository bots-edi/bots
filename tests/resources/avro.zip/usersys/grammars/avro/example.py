from bots.botsconfig import *

structure=    [
{ID:'HEA',MIN:1,MAX:1}
]
    
recorddefs = {
    'HEA':[
            ['BOTSID','C',3,'A'],
            ['name', 'M', 20, 'AN'],          
            ['favorite_number', 'C', 13, 'AN'],         
            ['favorite_color', 'C', 13, 'AN'] 
          ]
     }
