from bots.botsconfig import *

structure=    [
{ID:'HEA',MIN:1,MAX:1}
]
    
recorddefs = {
    'HEA':[
            ['BOTSID','C',3, 'A'],
            ['uuid', 'M', 256, 'UUID']
          ]
     }
